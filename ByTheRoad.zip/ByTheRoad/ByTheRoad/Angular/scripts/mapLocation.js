﻿function initMap() {
    if (google) {
        return true;
    }
}



